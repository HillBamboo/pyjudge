from distutils.core import setup

setup(
    name='pyjudge',
    version='0.1',
    packages=['pyjudge'],
    author='panmar',
    maintainer='HillBamboo'
)